const express = require('express');
const User = require('../model/User');
const { generateToken, verifyToken } = require('../middleware/auth');

const router = express.Router();

router.post('/register', async (req, res) => {
    try {
        const { namaPengguna, email, noTelepon, kataSandi, role } = req.body;

        if (!namaPengguna || !email || !kataSandi) {
        return res.status(400).json({
            success: false,
            message: 'Nama pengguna, email, dan kata sandi wajib diisi'
        });
        }

        const existingUser = await User.findByNamaPengguna(namaPengguna);
        const existingEmail = await User.findByEmail(email);

        if (existingUser) {
        return res.status(400).json({
            success: false,
            message: 'Nama pengguna sudah terdaftar'
        });
        }

        if (existingEmail) {
        return res.status(400).json({
            success: false,
            message: 'Email sudah terdaftar'
        });
        }

        const newUser = await User.create({
        namaPengguna,
        email,
        noTelepon,
        kataSandi,
        role
        });

        res.status(201).json({
        success: true,
        message: 'Registrasi berhasil',
        data: newUser
        });

    } catch (error) {
        console.error('Error register:', error);
        res.status(500).json({
        success: false,
        message: 'Terjadi kesalahan server'
        });
    }
});

router.post('/login', async (req, res) => {
    try {
        const { namaPengguna, kataSandi } = req.body;

        if (!namaPengguna || !kataSandi) {
        return res.status(400).json({
            success: false,
            message: 'Nama pengguna dan kata sandi wajib diisi'
        });
        }

        const user = await User.findByNamaPengguna(namaPengguna);

        if (!user) {
        return res.status(401).json({
            success: false,
            message: 'Nama pengguna atau kata sandi salah'
        });
        }

        const isPasswordValid = await User.verifyPassword(kataSandi, user.kata_sandi);

        if (!isPasswordValid) {
        return res.status(401).json({
            success: false,
            message: 'Nama pengguna atau kata sandi salah'
        });
    }

    const token = generateToken(user);

    res.json({
        success: true,
        message: 'Login berhasil',
        token,
        data: {
            id: user.id,
            nama_pengguna: user.nama_pengguna,
            email: user.email,
            no_telepon: user.no_telepon,
            role: user.role
        }
    });

    } catch (error) {
        console.error('Error login:', error);
        res.status(500).json({
        success: false,
        message: 'Terjadi kesalahan server'
        });
    }
});

router.get('/profile', verifyToken, async (req, res) => {
    try {
        const user = await User.findById(req.user.id);
        
        if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User tidak ditemukan'
        });
        }

        res.json({
        success: true,
        data: user
        });

    } catch (error) {
        console.error('Error get profile:', error);
        res.status(500).json({
        success: false,
        message: 'Terjadi kesalahan server'
        });
    }
});

module.exports = router;