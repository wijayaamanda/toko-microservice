const db = require("../config/database");
const bcrypt = require("bcryptjs");

class User {
    static async findByNamaPengguna(namaPengguna) {
        const result = await db.query(
        "SELECT * FROM users WHERE nama_pengguna = $1",
        [namaPengguna]
        );
        return result.rows[0];
    }

    static async findByEmail(email) {
        const result = await db.query("SELECT * FROM users WHERE email = $1", [
        email,
        ]);
        return result.rows[0];
    }

    static async create(userData) {
        const {
        namaPengguna,
        email,
        noTelepon,
        kataSandi,
        role = "kasir",
        } = userData;
        const hashedPassword = await bcrypt.hash(kataSandi, 10);

        const result = await db.query(
        `INSERT INTO users (nama_pengguna, email, no_telepon, kata_sandi, role)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING id, nama_pengguna, email, no_telepon, role`,
        [namaPengguna, email, noTelepon, hashedPassword, role]
        );

        return result.rows[0];
    }

    static async verifyPassword(plainPassword, hashedPassword) {
        return await bcrypt.compare(plainPassword, hashedPassword);
    }

    static async findById(id) {
        const result = await db.query(
        "SELECT id, nama_pengguna, email, no_telepon, role FROM users WHERE id = $1",
        [id]
        );
        return result.rows[0];
    }
}

module.exports = User;