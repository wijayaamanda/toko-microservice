const { Pool } = require('pg');

const pool = new Pool({
    host: process.env.DB_HOST || 'user-db',
    port: process.env.DB_PORT || 5432,
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'password123',
    database: process.env.DB_NAME || 'user_service'
});

(async () => {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS users (
                id SERIAL PRIMARY KEY,
                nama_pengguna VARCHAR(100) NOT NULL UNIQUE,
                email VARCHAR(100) NOT NULL UNIQUE,
                no_telepon VARCHAR(20),
                kata_sandi VARCHAR(255) NOT NULL,
                role VARCHAR(20) DEFAULT 'kasir',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log('Tabel user siap digunakan');
    } catch (err) {
        console.error('Error membuat tabel user:', err);
    }
})();

module.exports = pool;