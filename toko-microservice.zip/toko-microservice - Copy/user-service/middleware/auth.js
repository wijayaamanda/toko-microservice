const jwt = require('jsonwebtoken');
const JWT_SECRET = 'toko_microservice_secret_key_2024';

const verifyToken = (req, res, next) => {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    
    if (!token) {
        return res.status(401).json({ success: false, message: 'Token tidak ditemukan' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        res.status(401).json({ success: false, message: 'Token tidak valid' });
    }
};

const generateToken = (userData) => {
    return jwt.sign(
        { 
        id: userData.id, 
        nama_pengguna: userData.namaPengguna || userData.nama_pengguna,
        email: userData.email,
        role: userData.role
        },
        JWT_SECRET,
        { expiresIn: '24h' }
    );
};

module.exports = { verifyToken, generateToken, JWT_SECRET };