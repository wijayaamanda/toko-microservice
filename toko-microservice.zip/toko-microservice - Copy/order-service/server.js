const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const orderRoutes = require('./routes/orderRoutes');

const app = express();
const PORT = process.env.PORT || 3003;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/api', orderRoutes);

app.get('/', (req, res) => {
    res.json({ status: 'Order Service berjalan' });
});

app.listen(PORT, () => {
    console.log('Order Service berjalan di port ${PORT}');
});