const express = require('express');
const jwt = require('jsonwebtoken');
const axios = require('axios');
const Order = require('../model/Order');
const { generatePDF } = require('../utils/pdfGenerator');

const router = express.Router();
const JWT_SECRET = 'toko_microservice_secret_key_2024';

// Middleware untuk verifikasi token
const verifyToken = (req, res, next) => {
    const token = req.header('Authorization')?.replace('Bearer ', '');
    console.log('Token received:', token);

    if (!token) {
        return res.status(401).json({ success: false, message: 'Token tidak ditemukan' });
    }

    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        res.status(401).json({ success: false, message: 'Token tidak valid' });
    }
};

// Get all orders
router.get('/', verifyToken, async (req, res) => {
    try {
        const orders = await Order.getAll();
        res.json({
            success: true,
            data: orders
        });
    } catch (error) {
        console.error('Error get orders:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan server'
        });
    }
});

// Get order by ID
router.get('/:id', verifyToken, async (req, res) => {
    try {
        const order = await Order.getById(req.params.id);

        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Order tidak ditemukan'
            });
        }

        res.json({
            success: true,
            data: order
        });
    } catch (error) {
        console.error('Error get order:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan server'
        });
    }
});

// Create new order
router.post('/', verifyToken, async (req, res) => {
    try {
        const { items, jumlahBayar, tipePembayaran = 'CASH' } = req.body;
        const userId = req.user.id;
        const namaKasir = req.user.nama_pengguna;

        if (!items || items.length === 0) {
            return res.status(400).json({
                success: false,
                message: 'Items tidak boleh kosong'
            });
        }

        const kodeTransaksi = await Order.generateKodeTransaksi();

        let totalHarga = 0;
        const validatedItems = [];

        for (const item of items) {
            try {
                const produkResponse = await axios.get(
                    http://product-service:3002/api/product/${item.produkId},
                    {
                        headers: {
                            'Authorization': req.header('Authorization')
                        }
                    }
                );

                const produk = produkResponse.data.data;

                if (produk.stok < item.jumlah) {
                    return res.status(400).json({
                        success: false,
                        message: Stok ${produk.nama_produk} tidak mencukupi. Stok tersedia: ${produk.stok}
                    });
                }

                const subtotal = produk.harga * item.jumlah;
                totalHarga += subtotal;

                validatedItems.push({
                    produkId: produk.id,
                    namaProduk: produk.nama_produk,
                    harga: produk.harga,
                    jumlah: item.jumlah,
                    subtotal: subtotal
                });

                await axios.patch(
                    http://product-service:3002/api/product/${item.produkId}/stock,
                    { stok: produk.stok - item.jumlah },
                    {
                        headers: {
                            'Authorization': req.header('Authorization')
                        }
                    }
                );

            } catch (produkError) {
                console.error('Error validating produk:', produkError);
                return res.status(400).json({
                    success: false,
                    message: Produk dengan ID ${item.produkId} tidak ditemukan atau error validasi
                });
            }
        }

        if (jumlahBayar < totalHarga) {
            return res.status(400).json({
                success: false,
                message: 'Jumlah bayar tidak mencukupi'
            });
        }

        const kembalian = jumlahBayar - totalHarga;

        const newOrder = await Order.create({
            kodeTransaksi,
            userId,
            namaKasir,
            totalHarga,
            jumlahBayar,
            kembalian,
            tipePembayaran,
            items: validatedItems
        });

        // Kirim response JSON lebih dulu, PDF bisa diakses lewat endpoint /api/:id/pdf
        res.status(201).json({
            success: true,
            message: 'Order berhasil dibuat',
            data: {
                ...newOrder,
                pdf_url: /api/${newOrder.id}/pdf
            }
        });
        console.log('Order created successfully:', newOrder.id);
    } catch (error) {
        console.error('Error create order:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan server'
        });
    }
});

router.get('/:id/pdf', verifyToken, async (req, res) => {
    try {
        const order = await Order.getById(req.params.id);

        if (!order) {
            return res.status(404).json({
                success: false,
                message: 'Order tidak ditemukan'
            });
        }

        const pdfBuffer = await generatePDF(order);

        res.setHeader('Content-Type', 'application/pdf');
        res.setHeader('Content-Disposition', attachment; filename=struk-${order.kode_transaksi}.pdf);
        res.send(pdfBuffer);

        console.log('PDF generated successfully');

    } catch (error) {
        console.error('Error generate PDF:', error);
        res.status(500).json({
            success: false,
            message: 'Terjadi kesalahan saat generate PDF'
        });
    }
});

module.exports = router;