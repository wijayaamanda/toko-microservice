const puppeteer = require('puppeteer');

const generatePDF = async (order) => {
    const browser = await puppeteer.launch({
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH,
        args: ['--no-sandbox', '--disable-setuid-sandbox'],
        headless: true
    });
    const page = await browser.newPage();

    const htmlContent = `
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <style>
                body {
                    font-family: 'Courier New', monospace;
                    margin: 0;
                    padding: 20px;
                    font-size: 12px;
                    line-height: 1.4;
                }
                .receipt {
                    width: 300px;
                    margin: 0 auto;
                    border: 1px solid #000;
                    padding: 15px;
                }
                .header {
                    text-align: center;
                    border-bottom: 1px dashed #000;
                    padding-bottom: 10px;
                    margin-bottom: 10px;
                }
                .shop-name {
                    font-weight: bold;
                    font-size: 16px;
                }
                .info-row {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 5px;
                }
                .items {
                    border-bottom: 1px dashed #000;
                    padding-bottom: 10px;
                    margin-bottom: 10px;
                }
                .item-row {
                    margin-bottom: 8px;
                }
                .item-name {
                    font-weight: bold;
                }
                .item-detail {
                    display: flex;
                    justify-content: space-between;
                    font-size: 11px;
                }
                .total-section {
                    border-bottom: 1px dashed #000;
                    padding-bottom: 10px;
                    margin-bottom: 10px;
                }
                .total-row {
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 5px;
                }
                .total-row.grand {
                    font-weight: bold;
                    font-size: 14px;
                }
                .footer {
                    text-align: center;
                    margin-top: 10px;
                    font-style: italic;
                }
                .separator {
                    text-align: center;
                    margin: 10px 0;
                }
            </style>
        </head>
        <body>
            <div class="receipt">
                <div class="header">
                    <div class="shop-name">TOKO MIKROSERVICE</div>
                    <div>Jl. Teknologi No. 123 Kota Digital</div>
                </div>
                
                <div class="info-row">
                    <span>Kode Transaksi:</span>
                    <span>${order.kode_transaksi}</span>
                </div>
                <div class="info-row">
                    <span>Tanggal:</span>
                    <span>${new Date(order.created_at).toLocaleString('id-ID')}</span>
                </div>
                
                <div class="separator">================================</div>
                
                <div class="items">
                    <div style="display: flex; justify-content: space-between; font-weight: bold; margin-bottom: 8px;">
                        <span>Produk</span>
                        <span>Qty x Harga</span>
                        <span>Subtotal</span>
                    </div>
                    ${order.items.map(item => `
                        <div class="item-row">
                            <div class="item-name">${item.nama_produk}</div>
                            <div class="item-detail">
                                <span>${item.jumlah} x ${item.harga.toLocaleString('id-ID')}</span>
                                <span>${item.subtotal.toLocaleString('id-ID')}</span>
                            </div>
                        </div>
                    `).join('')}
                </div>
                
                <div class="total-section">
                    <div class="total-row grand">
                        <span>Total</span>
                        <span>Rp ${order.total_harga.toLocaleString('id-ID')}</span>
                    </div>
                    <div class="total-row">
                        <span>Jumlah Bayar</span>
                        <span>Rp ${order.jumlah_bayar.toLocaleString('id-ID')}</span>
                    </div>
                    <div class="total-row">
                        <span>Kembalian</span>
                        <span>Rp ${order.kembalian.toLocaleString('id-ID')}</span>
                    </div>
                    <div class="total-row">
                        <span>Tipe</span>
                        <span>${order.tipe_pembayaran}</span>
                    </div>
                </div>
                
                <div class="info-row">
                    <span>Kasir</span>
                    <span>${order.nama_kasir}</span>
                </div>
                
                <div class="separator">================================</div>
                
                <div class="footer">
                    Terima Kasih Atas Kunjungan Anda<br>
                    Barang yang sudah dibeli tidak dapat ditukar
                </div>
            </div>
        </body>
        </html>
    `;

    await page.setContent(htmlContent);

    const pdfBuffer = await page.pdf({
        format: 'A4',
        printBackground: true,
        margin: {
            top: '1cm',
            right: '1cm',
            bottom: '1cm',
            left: '1cm'
        }
    });

    await browser.close();
    return pdfBuffer;
};

module.exports = { generatePDF };