const { Pool } = require('pg');

const pool = new Pool({
    host: process.env.DB_HOST || 'order-db',
    port: process.env.DB_PORT || 5432,
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'password123',
    database: process.env.DB_NAME || 'order_service'
});

(async () => {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS orders (
                id SERIAL PRIMARY KEY,
                kode_transaksi VARCHAR(50) NOT NULL UNIQUE,
                user_id INT NOT NULL,
                nama_kasir VARCHAR(100) NOT NULL,
                total_harga DECIMAL(10, 2) NOT NULL,
                jumlah_bayar DECIMAL(10, 2) NOT NULL,
                kembalian DECIMAL(10, 2) NOT NULL,
                tipe_pembayaran VARCHAR(20) DEFAULT 'CASH',
                status VARCHAR(20) DEFAULT 'completed',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        
        await pool.query(`
            CREATE TABLE IF NOT EXISTS order_items (
                id SERIAL PRIMARY KEY,
                order_id INT NOT NULL,
                produk_id INT NOT NULL,
                nama_produk VARCHAR(255) NOT NULL,
                harga DECIMAL(10, 2) NOT NULL,
                jumlah INT NOT NULL,
                subtotal DECIMAL(10, 2) NOT NULL,
                CONSTRAINT fk_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
            )
        `);
        
        console.log('Tabel orders dan order_items siap digunakan');
    } catch (err) {
        console.error('Error membuat tabel:', err);
    }
})();

module.exports = pool;