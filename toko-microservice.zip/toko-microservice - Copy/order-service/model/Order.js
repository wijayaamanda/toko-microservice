const pool = require('../config/database');

class Order {
    static async getAll() {
        const query = `
        SELECT o.*,
            COALESCE(
            json_agg(
                json_build_object(
                'nama_produk', oi.nama_produk,
                'jumlah', oi.jumlah,
                'harga', oi.harga,
                'subtotal', oi.subtotal
                )
            ) FILTER (WHERE oi.id IS NOT NULL), '[]'
            ) as items
        FROM orders o
        LEFT JOIN order_items oi ON o.id = oi.order_id
        GROUP BY o.id
        ORDER BY o.created_at DESC
        `;
        const { rows } = await pool.query(query);
        return rows;
    }

    static async getById(id) {
        const orderQuery = `SELECT * FROM orders WHERE id = $1`;
        const itemsQuery = `SELECT * FROM order_items WHERE order_id = $1`;

        const orderRes = await pool.query(orderQuery, [id]);
        if (orderRes.rows.length === 0) return null;

        const itemsRes = await pool.query(itemsQuery, [id]);
        return { ...orderRes.rows[0], items: itemsRes.rows };
    }

    static async create(orderData) {
        const {
        kodeTransaksi,
        userId,
        namaKasir,
        totalHarga,
        jumlahBayar,
        kembalian,
        tipePembayaran,
        items,
        } = orderData;

        const client = await pool.connect();
        try {
        await client.query('BEGIN');

        const insertOrder = `
            INSERT INTO orders 
            (kode_transaksi, user_id, nama_kasir, total_harga, jumlah_bayar, kembalian, tipe_pembayaran)
            VALUES ($1,$2,$3,$4,$5,$6,$7) RETURNING id
        `;
        const orderRes = await client.query(insertOrder, [
            kodeTransaksi,
            userId,
            namaKasir,
            totalHarga,
            jumlahBayar,
            kembalian,
            tipePembayaran,
        ]);

        const orderId = orderRes.rows[0].id;

        if (items && items.length > 0) {
            const insertItems = `
            INSERT INTO order_items 
            (order_id, produk_id, nama_produk, harga, jumlah, subtotal)
            VALUES ${items.map(
                (_, i) =>
                `($1, $${i * 5 + 2}, $${i * 5 + 3}, $${i * 5 + 4}, $${i * 5 + 5}, $${i * 5 + 6})`
            ).join(',')}
            `;

            const values = items.flatMap((item) => [
            item.produkId,
            item.namaProduk,
            item.harga,
            item.jumlah,
            item.subtotal,
            ]);

            await client.query(insertItems, [orderId, ...values]);
        }

        await client.query('COMMIT');

        return {
            id: orderId,
            kode_transaksi: kodeTransaksi,
            user_id: userId,
            nama_kasir: namaKasir,
            total_harga: totalHarga,
            jumlah_bayar: jumlahBayar,
            kembalian,
            tipe_pembayaran: tipePembayaran,
            items,
        };
        } catch (err) {
        await client.query('ROLLBACK');
        throw err;
        } finally {
        client.release();
        }
    }

    static async generateKodeTransaksi() {
        const today = new Date();
        const prefix = `TRX${today.getFullYear().toString().slice(-2)}${String(
        today.getMonth() + 1
        ).padStart(2, '0')}${String(today.getDate()).padStart(2, '0')}`;

        const query = `
            SELECT COUNT(*)::int as count 
            FROM orders 
            WHERE kode_transaksi LIKE $1 
            AND DATE(created_at) = CURRENT_DATE
        `;
        const { rows } = await pool.query(query, [`${prefix}%`]);
        const kodeTransaksi = `${prefix}${String(rows[0].count + 1).padStart(3, '0')}`;
        return kodeTransaksi;
    }
}

module.exports = Order;