const db = require("./product-service/config/database");

(async () => {
    try {
        const result = await db.query("SELECT NOW() as current_time, version() as pg_version");
        console.log("✅ Database connected successfully!");
        console.log("Current time:", result.rows[0].current_time);
        console.log("PostgreSQL version:", result.rows[0].pg_version);
        
        // Test produk table
        const produkTest = await db.query("SELECT COUNT(*) as total FROM produk");
        console.log("Total produk in database:", produkTest.rows[0].total);
        
    } catch (error) {
        console.error("❌ Database connection failed:", error.message);
    } finally {
        process.exit();
    }
})();