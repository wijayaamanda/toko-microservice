import axios from 'axios';
import { User, Produk, Order, ApiResponse } from '../types';

const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:3000/api';

const apiClient = axios.create({
    baseURL: API_BASE_URL,
    headers: {
        'Content-Type': 'application/json',
    },
});

apiClient.interceptors.request.use(
    (config) => {
        const token = localStorage.getItem('token');
        if (token) {
            config.headers.Authorization = `Bearer ${token}`;
        }
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

apiClient.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response?.status === 401) {
        localStorage.removeItem('token');
        localStorage.removeItem('user');
        window.location.href = '/login';
        }
        return Promise.reject(error);
    }
);

export const authService = {
    login: async (namaPengguna: string, kataSandi: string): Promise<ApiResponse<User>> => {
        const response = await apiClient.post('/auth/login', {
        namaPengguna,
        kataSandi
        });
        return response.data;
    },

    register: async (userData: {
        namaPengguna: string;
        email: string;
        noTelepon?: string;
        kataSandi: string;
        role?: string;
    }): Promise<ApiResponse<User>> => {
        const response = await apiClient.post('/auth/register', userData);
        return response.data;
    },

    getProfile: async (): Promise<ApiResponse<User>> => {
        const response = await apiClient.get('/auth/profile');
        return response.data;
    }
};

export const produkService = {
    getAll: async (): Promise<ApiResponse<Produk[]>> => {
        const response = await apiClient.get('/product');
        return response.data;
    },

    getById: async (id: number): Promise<ApiResponse<Produk>> => {
        const response = await apiClient.get(`/product/${id}`);
        return response.data;
    },

    create: async (produkData: Omit<Produk, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<Produk>> => {
        const response = await apiClient.post('/product', produkData);
        return response.data;
    },

    update: async (id: number, produkData: Omit<Produk, 'id' | 'created_at' | 'updated_at'>): Promise<ApiResponse<Produk>> => {
        const response = await apiClient.put(`/product/${id}`, produkData);
        return response.data;
    },

    delete: async (id: number): Promise<ApiResponse<any>> => {
        const response = await apiClient.delete(`/product/${id}`);
        return response.data;
    }
};

export const orderService = {
    getAll: async (): Promise<ApiResponse<Order[]>> => {
        const response = await apiClient.get('/orders');
        return response.data;
    },

    getById: async (id: number): Promise<ApiResponse<Order>> => {
        const response = await apiClient.get(`/orders/${id}`);
        return response.data;
    },

    create: async (orderData: {
        items: Array<{ produkId: number; jumlah: number }>;
        jumlahBayar: number;
        tipePembayaran: 'CASH' | 'DEBIT' | 'KREDIT';
    }): Promise<ApiResponse<Order>> => {
        const response = await apiClient.post('/orders', orderData);
        return response.data;
    },

    generatePDF: async (id: number): Promise<Blob> => {
        const response = await apiClient.get(`/orders/${id}/pdf`, {
        responseType: 'blob'
        });
        return response.data;
    }
};

export default apiClient;