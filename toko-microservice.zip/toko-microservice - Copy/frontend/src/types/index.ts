export interface User {
    id: number;
    nama_pengguna: string;
    email: string;
    no_telepon?: string;
    role: 'admin' | 'kasir';
}

export interface Produk {
    id: number;
    nama_produk: string;
    harga: number;
    stok: number;
    deskripsi?: string;
    kategori?: string;
    created_at: string;
    updated_at: string;
}

export interface OrderItem {
    produkId: number;
    namaProduk: string;
    harga: number;
    jumlah: number;
    subtotal: number;
}

export interface Order {
    id: number;
    kode_transaksi: string;
    user_id: number;
    nama_kasir: string;
    total_harga: number;
    jumlah_bayar: number;
    kembalian: number;
    tipe_pembayaran: 'CASH' | 'DEBIT' | 'KREDIT';
    status: 'pending' | 'completed' | 'cancelled';
    created_at: string;
    items: OrderItem[];
}

export interface CartItem {
    produk: Produk;
    quantity: number;
}

export interface ApiResponse<T> {
    success: boolean;
    message: string;
    data?: T;
    token?: string;
}