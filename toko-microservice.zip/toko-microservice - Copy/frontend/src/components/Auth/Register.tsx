import React, { useState } from 'react';
import { authService } from '../../services/apiService';

interface RegisterProps {
    onRegisterSuccess: () => void;
    onSwitchToLogin: () => void;
    }

    const Register: React.FC<RegisterProps> = ({ onRegisterSuccess, onSwitchToLogin }) => {
    const [formData, setFormData] = useState({
        namaPengguna: '',
        email: '',
        noTelepon: '',
        kataSandi: '',
        konfirmasiSandi: '',
        role: 'kasir'
    });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
        setFormData({
        ...formData,
        [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        if (formData.kataSandi !== formData.konfirmasiSandi) {
        setError('Konfirmasi kata sandi tidak cocok');
        setLoading(false);
        return;
        }

        if (formData.kataSandi.length < 6) {
        setError('Kata sandi minimal 6 karakter');
        setLoading(false);
        return;
        }

        try {
        const result = await authService.register({
            namaPengguna: formData.namaPengguna,
            email: formData.email,
            noTelepon: formData.noTelepon,
            kataSandi: formData.kataSandi,
            role: formData.role
        });
        
        if (result.success) {
            alert('Registrasi berhasil! Silakan login.');
            onRegisterSuccess();
        } else {
            setError(result.message || 'Registrasi gagal');
        }
        } catch (err: any) {
        setError(err.response?.data?.message || 'Terjadi kesalahan');
        } finally {
        setLoading(false);
        }
    };

    return (
        <div className="auth-form">
        <h2>Daftar Akun Baru</h2>
        <form onSubmit={handleSubmit}>
            <div className="form-group">
            <label htmlFor="namaPengguna">Nama Pengguna:</label>
            <input
                type="text"
                id="namaPengguna"
                name="namaPengguna"
                value={formData.namaPengguna}
                onChange={handleInputChange}
                required
                disabled={loading}
            />
            </div>

            <div className="form-group">
            <label htmlFor="email">Email:</label>
            <input
                type="email"
                id="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                required
                disabled={loading}
            />
            </div>

            <div className="form-group">
            <label htmlFor="noTelepon">No. Telepon:</label>
            <input
                type="tel"
                id="noTelepon"
                name="noTelepon"
                value={formData.noTelepon}
                onChange={handleInputChange}
                disabled={loading}
            />
            </div>

            <div className="form-group">
            <label htmlFor="role">Role:</label>
            <select
                id="role"
                name="role"
                value={formData.role}
                onChange={handleInputChange}
                disabled={loading}
            >
                <option value="kasir">Kasir</option>
                <option value="admin">Admin</option>
            </select>
            </div>

            <div className="form-group">
            <label htmlFor="kataSandi">Kata Sandi:</label>
            <input
                type="password"
                id="kataSandi"
                name="kataSandi"
                value={formData.kataSandi}
                onChange={handleInputChange}
                required
                disabled={loading}
                minLength={6}
            />
            </div>

            <div className="form-group">
            <label htmlFor="konfirmasiSandi">Konfirmasi Kata Sandi:</label>
            <input
                type="password"
                id="konfirmasiSandi"
                name="konfirmasiSandi"
                value={formData.konfirmasiSandi}
                onChange={handleInputChange}
                required
                disabled={loading}
                minLength={6}
            />
            </div>

            <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? 'Mendaftar...' : 'Daftar'}
            </button>
        </form>

        {error && <div className="error-message">{error}</div>}

        <div className="auth-switch">
            <p>
            Sudah punya akun? 
            <button type="button" onClick={onSwitchToLogin} className="btn-link">
                Masuk di sini
            </button>
            </p>
        </div>
        </div>
    );
};

export default Register;