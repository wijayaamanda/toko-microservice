import React, { useState } from 'react';
import { authService } from '../../services/apiService';

interface LoginProps {
    onLoginSuccess: (user: any) => void;
    onSwitchToRegister: () => void;
    }

    const Login: React.FC<LoginProps> = ({ onLoginSuccess, onSwitchToRegister }) => {
    const [formData, setFormData] = useState({
        namaPengguna: '',
        kataSandi: ''
    });
    const [error, setError] = useState('');
    const [loading, setLoading] = useState(false);

    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setFormData({
        ...formData,
        [e.target.name]: e.target.value
        });
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        setLoading(true);
        setError('');

        try {
        const result = await authService.login(formData.namaPengguna, formData.kataSandi);
        
        if (result.success && result.token && result.data) {
            localStorage.setItem('token', result.token);
            localStorage.setItem('user', JSON.stringify(result.data));
            onLoginSuccess(result.data);
        } else {
            setError(result.message || 'Login gagal');
        }
        } catch (err: any) {
        setError(err.response?.data?.message || 'Terjadi kesalahan');
        } finally {
        setLoading(false);
        }
    };

    return (
        <div className="auth-form">
        <h2>Masuk ke Akun</h2>
        <form onSubmit={handleSubmit}>
            <div className="form-group">
            <label htmlFor="namaPengguna">Nama Pengguna:</label>
            <input
                type="text"
                id="namaPengguna"
                name="namaPengguna"
                value={formData.namaPengguna}
                onChange={handleInputChange}
                required
                disabled={loading}
            />
            </div>

            <div className="form-group">
            <label htmlFor="kataSandi">Kata Sandi:</label>
            <input
                type="password"
                id="kataSandi"
                name="kataSandi"
                value={formData.kataSandi}
                onChange={handleInputChange}
                required
                disabled={loading}
            />
            </div>

            <button type="submit" className="btn-primary" disabled={loading}>
            {loading ? 'Masuk...' : 'Masuk'}
            </button>
        </form>

        {error && <div className="error-message">{error}</div>}

        <div className="auth-switch">
            <p>
            Belum punya akun? 
            <button type="button" onClick={onSwitchToRegister} className="btn-link">
                Daftar di sini
            </button>
            </p>
        </div>
        </div>
    );
};

export default Login;