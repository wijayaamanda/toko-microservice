import React, { useState, useEffect } from 'react';
import { Produk } from '../../types/index';
import { produkService, orderService } from '../../services/apiService';
// import apiClient from './apiService';


interface OrderFormProps {
    onSuccess: () => void;
    onCancel: () => void;
}

interface OrderFormItem {
    produk: Produk;
    jumlah: number;
    subtotal: number;
}

const OrderForm: React.FC<OrderFormProps> = ({ onSuccess, onCancel }) => {
    const [availableProduk, setAvailableProduk] = useState<Produk[]>([]);
    const [orderItems, setOrderItems] = useState<OrderFormItem[]>([]);
    const [paymentData, setPaymentData] = useState({
        jumlahBayar: '',
        tipePembayaran: 'CASH' as 'CASH' | 'DEBIT' | 'KREDIT'
    });
    const [selectedProduk, setSelectedProduk] = useState<number | ''>('');
    const [selectedQuantity, setSelectedQuantity] = useState<number>(1);
    const [loading, setLoading] = useState(false);
    const [loadingProduk, setLoadingProduk] = useState(true);
    const [error, setError] = useState('');

    useEffect(() => {
        loadProduk();
    }, []);

    const loadProduk = async () => {
        try {
            setLoadingProduk(true);
            const result = await produkService.getAll();
            if (result.success && result.data) {
                setAvailableProduk(result.data.filter(p => p.stok > 0));
            }
        } catch (err: any) {
            setError('Gagal memuat produk');
            console.error(err);
        } finally {
            setLoadingProduk(false);
        }
    };

    const addItemToOrder = () => {
        if (!selectedProduk) {
            alert('Pilih produk terlebih dahulu');
            return;
        }

        const produk = availableProduk.find(p => p.id === selectedProduk);
        if (!produk) return;

        const existingItemIndex = orderItems.findIndex(item => item.produk.id === selectedProduk);

        if (existingItemIndex >= 0) {
            const newQuantity = orderItems[existingItemIndex].jumlah + selectedQuantity;

            if (newQuantity > produk.stok) {
                alert(`Stok ${produk.nama_produk} tidak mencukupi`);
                return;
            }

            const updatedItems = [...orderItems];
            updatedItems[existingItemIndex] = {
                ...updatedItems[existingItemIndex],
                jumlah: newQuantity,
                subtotal: newQuantity * produk.harga
            };
            setOrderItems(updatedItems);
        } else {
            if (selectedQuantity > produk.stok) {
                alert(`Stok ${produk.nama_produk} tidak mencukupi`);
                return;
            }

            const newItem: OrderFormItem = {
                produk,
                jumlah: selectedQuantity,
                subtotal: selectedQuantity * produk.harga
            };
            setOrderItems([...orderItems, newItem]);
        }

        setSelectedProduk('');
        setSelectedQuantity(1);
    };

    const updateItemQuantity = (produkId: number, newQuantity: number) => {
        if (newQuantity <= 0) {
            removeItem(produkId);
            return;
        }

        const produk = availableProduk.find(p => p.id === produkId);
        if (!produk) return;

        if (newQuantity > produk.stok) {
            alert(`Stok ${produk.nama_produk} tidak mencukupi`);
            return;
        }

        setOrderItems(orderItems.map(item =>
            item.produk.id === produkId
                ? { ...item, jumlah: newQuantity, subtotal: newQuantity * item.produk.harga }
                : item
        ));
    };

    const removeItem = (produkId: number) => {
        setOrderItems(orderItems.filter(item => item.produk.id !== produkId));
    };

    const getTotalPrice = () => {
        return orderItems.reduce((total, item) => total + item.subtotal, 0);
    };

    const getChange = () => {
        const paymentAmount = parseFloat(paymentData.jumlahBayar || '0');
        return Math.max(0, paymentAmount - getTotalPrice());
    };

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();

        if (orderItems.length === 0) {
            alert('Tambahkan minimal satu produk');
            return;
        }

        const totalPrice = getTotalPrice();
        const paymentAmount = parseFloat(paymentData.jumlahBayar);

        if (!paymentAmount || paymentAmount < totalPrice) {
            alert('Jumlah bayar tidak valid atau kurang');
            return;
        }

        setLoading(true);
        setError('');

        try {
            const orderData = {
                items: orderItems.map(item => ({
                    produkId: item.produk.id,
                    jumlah: item.jumlah
                })),
                jumlahBayar: paymentAmount,
                tipePembayaran: paymentData.tipePembayaran
            };

            const result = await orderService.create(orderData);

            if (result.success) {
                alert(`Transaksi berhasil! Kode: ${result.data?.kode_transaksi}`);

                if (result.data) {
                    setTimeout(() => {
                        handleDownloadPDF(result.data!.id, result.data!.kode_transaksi);
                    }, 500);
                }

                onSuccess();
            }
        } catch (err: any) {
            setError(err.response?.data?.message || 'Transaksi gagal');
        } finally {
            setLoading(false);
        }
    };

    const handleDownloadPDF = async (orderId: number, kodeTransaksi: string) => {
        try {
            const pdfBlob = await orderService.generatePDF(orderId);

            const url = window.URL.createObjectURL(pdfBlob);
            const link = document.createElement('a');
            link.href = url;
            link.download = `struk-${kodeTransaksi}.pdf`;
            document.body.appendChild(link);
            link.click();
            link.remove();
            window.URL.revokeObjectURL(url);
        } catch (err) {
            console.error('Error download PDF:', err);
        }
    };

    const getAvailableQuantity = (produkId: number) => {
        const produk = availableProduk.find(p => p.id === produkId);
        if (!produk) return 0;

        const usedInOrder = orderItems.find(item => item.produk.id === produkId)?.jumlah || 0;
        return produk.stok - usedInOrder;
    };

    return (
        <div className="modal-overlay">
            <div className="modal order-form-modal">
                <div className="modal-header">
                    <h3>Buat Transaksi Baru</h3>
                    <button
                        type="button"
                        className="btn-close"
                        onClick={onCancel}
                        disabled={loading}
                    >
                        ×
                    </button>
                </div>

                <div className="order-form-content">
                    {error && <div className="error-message">{error}</div>}

                    <div className="produK-selection">
                        <h4>Pilih Produk</h4>

                        {loadingProduk ? (
                            <div className="loading">Memuat produk...</div>
                        ) : (
                            <div className="add-produK-form">
                                <div className="form-row">
                                    <div className="form-group">
                                        <select
                                            value={selectedProduk}
                                            onChange={(e) => setSelectedProduk(e.target.value ? parseInt(e.target.value) : '')}
                                            disabled={loading}
                                        >
                                            <option value="">Pilih Produk</option>
                                            {availableProduk.map(produk => {
                                                const availableQty = getAvailableQuantity(produk.id);
                                                return (
                                                    <option
                                                        key={produk.id}
                                                        value={produk.id}
                                                        disabled={availableQty === 0}
                                                    >
                                                        {produk.nama_produk} - Rp {produk.harga.toLocaleString('id-ID')}
                                                        (Tersedia: {availableQty})
                                                    </option>
                                                );
                                            })}
                                        </select>
                                    </div>

                                    <div className="form-group quantity-group">
                                        <input
                                            type="number"
                                            min="1"
                                            max={selectedProduk ? getAvailableQuantity(Number(selectedProduk)) : 1}
                                            value={selectedQuantity}
                                            onChange={(e) => setSelectedQuantity(parseInt(e.target.value) || 1)}
                                            disabled={loading || !selectedProduk}
                                            placeholder="Qty"
                                        />
                                    </div>

                                    <button
                                        type="button"
                                        className="btn-primary btn-sm"
                                        onClick={addItemToOrder}
                                        disabled={loading || !selectedProduk}
                                    >
                                        Tambah
                                    </button>
                                </div>
                            </div>
                        )}
                    </div>

                    <div className="order-items-section">
                        <h4>Item Pesanan ({orderItems.length})</h4>

                        {orderItems.length === 0 ? (
                            <div className="no-items">Belum ada item yang dipilih</div>
                        ) : (
                            <div className="order-items-list">
                                {orderItems.map(item => (
                                    <div key={item.produk.id} className="order-item-row">
                                        <div className="item-details">
                                            <strong>{item.produk.nama_produk}</strong>
                                            <div className="item-price">
                                                Rp {item.produk.harga.toLocaleString('id-ID')} × {item.jumlah}
                                            </div>
                                        </div>

                                        <div className="item-controls">
                                            <div className="quantity-controls">
                                                <button
                                                    type="button"
                                                    onClick={() => updateItemQuantity(item.produk.id, item.jumlah - 1)}
                                                    disabled={loading}
                                                >
                                                    -
                                                </button>
                                                <span>{item.jumlah}</span>
                                                <button
                                                    type="button"
                                                    onClick={() => updateItemQuantity(item.produk.id, item.jumlah + 1)}
                                                    disabled={loading}
                                                >
                                                    +
                                                </button>
                                            </div>

                                            <div className="item-subtotal">
                                                Rp {item.subtotal.toLocaleString('id-ID')}
                                            </div>

                                            <button
                                                type="button"
                                                className="btn-danger btn-sm"
                                                onClick={() => removeItem(item.produk.id)}
                                                disabled={loading}
                                            >
                                                Hapus
                                            </button>
                                        </div>
                                    </div>
                                ))}
                            </div>
                        )}

                        {orderItems.length > 0 && (
                            <div className="order-total">
                                <strong>Total: Rp {getTotalPrice().toLocaleString('id-ID')}</strong>
                            </div>
                        )}
                    </div>

                    {/* Payment Form */}
                    {orderItems.length > 0 && (
                        <form onSubmit={handleSubmit} className="payment-form">
                            <h4>Pembayaran</h4>

                            <div className="form-row">
                                <div className="form-group">
                                    <label>Jumlah Bayar:</label>
                                    <input
                                        type="number"
                                        min={getTotalPrice()}
                                        step="1000"
                                        value={paymentData.jumlahBayar}
                                        onChange={(e) => setPaymentData({
                                            ...paymentData,
                                            jumlahBayar: e.target.value
                                        })}
                                        required
                                        disabled={loading}
                                        placeholder={`Minimal Rp ${getTotalPrice().toLocaleString('id-ID')}`}
                                    />
                                </div>

                                <div className="form-group">
                                    <label>Tipe Pembayaran:</label>
                                    <select
                                        value={paymentData.tipePembayaran}
                                        onChange={(e) => setPaymentData({
                                            ...paymentData,
                                            tipePembayaran: e.target.value as 'CASH' | 'DEBIT' | 'KREDIT'
                                        })}
                                        disabled={loading}
                                    >
                                        <option value="CASH">Cash</option>
                                        <option value="DEBIT">Debit</option>
                                        <option value="KREDIT">Kredit</option>
                                    </select>
                                </div>
                            </div>

                            {paymentData.jumlahBayar && (
                                <div className="change-display">
                                    <strong>Kembalian: Rp {getChange().toLocaleString('id-ID')}</strong>
                                </div>
                            )}

                            <div className="form-actions">
                                <button
                                    type="button"
                                    className="btn-secondary"
                                    onClick={onCancel}
                                    disabled={loading}
                                >
                                    Batal
                                </button>
                                <button
                                    type="submit"
                                    className="btn-primary"
                                    disabled={loading || orderItems.length === 0}
                                >
                                    {loading ? 'Memproses...' : 'Bayar & Cetak Struk'}
                                </button>
                            </div>
                        </form>
                    )}
                </div>
            </div>
        </div>
    );
};

export default OrderForm;