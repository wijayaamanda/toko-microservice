import React, { useState, useEffect } from 'react';
import { Order } from '../../types';
import { orderService } from '../../services/apiService';
import OrderForm from './OrderForm';

const OrderList: React.FC = () => {
    const [orders, setOrders] = useState<Order[]>([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [showOrderForm, setShowOrderForm] = useState(false);

    useEffect(() => {
        loadOrders();
    }, []);

    const loadOrders = async () => {
        try {
        setLoading(true);
        const result = await orderService.getAll();
        if (result.success && result.data) {
            setOrders(result.data);
        }
        } catch (err: any) {
        setError('Gagal memuat daftar transaksi');
        console.error(err);
        } finally {
        setLoading(false);
        }
    };

    const handleDownloadPDF = async (orderId: number, kodeTransaksi: string) => {
        try {
        const pdfBlob = await orderService.generatePDF(orderId);
        
        const url = window.URL.createObjectURL(pdfBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `struk-${kodeTransaksi}.pdf`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(url);
        } catch (err) {
        alert('Gagal download PDF struk');
        }
    };

    const handleFormSuccess = () => {
        setShowOrderForm(false);
        loadOrders();
    };

    const handleFormCancel = () => {
        setShowOrderForm(false);
    };

    if (loading) return <div className="loading">Memuat transaksi...</div>;

    return (
        <div className="order-list">
        <div className="page-header">
            <h2>Daftar Transaksi</h2>
            <div className="header-actions">
            <button 
                className="btn-primary"
                onClick={() => setShowOrderForm(true)}
            >
                Buat Transaksi Manual
            </button>
            <button onClick={loadOrders} className="btn-secondary">
                Refresh
            </button>
            </div>
        </div>

        {error && <div className="error-message">{error}</div>}

        {showOrderForm && (
            <OrderForm
            onSuccess={handleFormSuccess}
            onCancel={handleFormCancel}
            />
        )}

        <div className="orders-table">
            {orders.length === 0 ? (
            <div className="no-data">
                <p>Belum ada transaksi.</p>
                <p>Buat transaksi pertama dengan tombol "Buat Transaksi Manual" di atas.</p>
            </div>
            ) : (
            <table>
                <thead>
                <tr>
                    <th>Kode Transaksi</th>
                    <th>Kasir</th>
                    <th>Total</th>
                    <th>Bayar</th>
                    <th>Kembalian</th>
                    <th>Tipe</th>
                    <th>Tanggal</th>
                    <th>Items</th>
                    <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                {orders.map(order => (
                    <tr key={order.id}>
                    <td>
                        <span className="transaction-code">{order.kode_transaksi}</span>
                    </td>
                    <td>{order.nama_kasir}</td>
                    <td className="price-cell">
                        Rp {order.total_harga.toLocaleString('id-ID')}
                    </td>
                    <td className="price-cell">
                        Rp {order.jumlah_bayar.toLocaleString('id-ID')}
                    </td>
                    <td className="price-cell">
                        Rp {order.kembalian.toLocaleString('id-ID')}
                    </td>
                    <td>
                        <span className={`payment-type payment-${order.tipe_pembayaran.toLowerCase()}`}>
                        {order.tipe_pembayaran}
                        </span>
                    </td>
                    <td className="date-cell">
                        {new Date(order.created_at).toLocaleDateString('id-ID', {
                        day: '2-digit',
                        month: '2-digit', 
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                        })}
                    </td>
                    <td className="items-cell">
                        {order.items?.map((item, index) => (
                        <div key={index} className="order-item">
                            {item.namaProduk} ({item.jumlah}x)
                        </div>
                        ))}
                    </td>
                    <td className="action-cell">
                        <button 
                        className="btn-primary btn-sm"
                        onClick={() => handleDownloadPDF(order.id, order.kode_transaksi)}
                        title="Download PDF Struk"
                        >
                        📄 PDF
                        </button>
                    </td>
                    </tr>
                ))}
                </tbody>
            </table>
            )}
        </div>
        </div>
    );
};

export default OrderList;