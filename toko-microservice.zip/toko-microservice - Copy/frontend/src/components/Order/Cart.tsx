import React, { useState, useEffect } from 'react';
import { Produk, CartItem } from '../../types';
import { produkService, orderService } from '../../services/apiService';

const Cart: React.FC = () => {
    const [produk, setProduk] = useState<Produk[]>([]);
    const [cartItems, setCartItems] = useState<CartItem[]>([]);
    const [loading, setLoading] = useState(true);
    const [submitting, setSubmitting] = useState(false);
    const [paymentForm, setPaymentForm] = useState({
        jumlahBayar: '',
        tipePembayaran: 'CASH' as 'CASH' | 'DEBIT' | 'KREDIT'
    });
    const [error, setError] = useState('');

    useEffect(() => {
        loadProduk();
    }, []);

    const loadProduk = async () => {
        try {
        setLoading(true);
        const result = await produkService.getAll();
        if (result.success && result.data) {
            setProduk(result.data.filter(p => p.stok > 0));
        }
        } catch (err: any) {
        setError('Gagal memuat produk');
        console.error(err);
        } finally {
        setLoading(false);
        }
    };

    const addToCart = (produk: Produk) => {
        const existingItem = cartItems.find(item => item.produk.id === produk.id);
        
        if (existingItem) {
        if (existingItem.quantity >= produk.stok) {
            alert(`Stok ${produk.nama_produk} tidak mencukupi`);
            return;
        }
        
        setCartItems(cartItems.map(item =>
            item.produk.id === produk.id
            ? { ...item, quantity: item.quantity + 1 }
            : item
        ));
        } else {
        setCartItems([...cartItems, { produk, quantity: 1 }]);
        }
    };

    const updateQuantity = (produkId: number, newQuantity: number) => {
        if (newQuantity === 0) {
        removeFromCart(produkId);
        return;
        }

        const produks = produk.find(p => p.id === produkId);
        if (produks && newQuantity > produks.stok) {
        alert(`Stok ${produks.nama_produk} tidak mencukupi`);
        return;
        }

        setCartItems(cartItems.map(item =>
        item.produk.id === produkId
            ? { ...item, quantity: newQuantity }
            : item
        ));
    };

    const removeFromCart = (produkId: number) => {
        setCartItems(cartItems.filter(item => item.produk.id !== produkId));
    };

    const getTotalPrice = () => {
        return cartItems.reduce((total, item) => total + (item.produk.harga * item.quantity), 0);
    };

    const handlePaymentSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        
        if (cartItems.length === 0) {
        alert('Keranjang kosong');
        return;
        }

        const totalPrice = getTotalPrice();
        const paymentAmount = parseFloat(paymentForm.jumlahBayar);

        if (paymentAmount < totalPrice) {
        alert('Jumlah bayar kurang');
        return;
        }

        setSubmitting(true);
        setError('');

        try {
        const orderData = {
            items: cartItems.map(item => ({
            produkId: item.produk.id,
            jumlah: item.quantity
            })),
            jumlahBayar: paymentAmount,
            tipePembayaran: paymentForm.tipePembayaran
        };

        const result = await orderService.create(orderData);

        if (result.success) {
            alert(`Transaksi berhasil! Kode: ${result.data?.kode_transaksi}`);
            
            setCartItems([]);
            setPaymentForm({ jumlahBayar: '', tipePembayaran: 'CASH' });
            
            loadProduk();

            if (result.data) {
            setTimeout(() => {
                handleDownloadPDF(result.data!.id, result.data!.kode_transaksi);
            }, 1000);
            }
        }
        } catch (err: any) {
        setError(err.response?.data?.message || 'Transaksi gagal');
        } finally {
        setSubmitting(false);
        }
    };

    const handleDownloadPDF = async (orderId: number, kodeTransaksi: string) => {
        try {
        const pdfBlob = await orderService.generatePDF(orderId);
        
        const url = window.URL.createObjectURL(pdfBlob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `struk-${kodeTransaksi}.pdf`;
        document.body.appendChild(link);
        link.click();
        link.remove();
        window.URL.revokeObjectURL(url);
        } catch (err) {
        console.error('Error download PDF:', err);
        }
    };

    if (loading) return <div className="loading">Memuat produk...</div>;

    return (
        <div className="cart-page">
        <h2>Keranjang Belanja</h2>
        
        <div className="cart-layout">
            <div className="produk-section">
            <h3>Pilih Produk</h3>
            {error && <div className="error-message">{error}</div>}
            
            <div className="produk-grid">
                {produk.map(produk => (
                <div key={produk.id} className="produk-card">
                    <h4>{produk.nama_produk}</h4>
                    <p className="price">Rp {produk.harga.toLocaleString('id-ID')}</p>
                    <p className="stock">Stok: {produk.stok}</p>
                    <button 
                    className="btn-primary btn-sm"
                    onClick={() => addToCart(produk)}
                    disabled={produk.stok === 0}
                    >
                    Tambah ke Keranjang
                    </button>
                </div>
                ))}
            </div>
            </div>

            {/* Cart */}
            <div className="cart-section">
            <h3>Keranjang ({cartItems.length} item)</h3>
            
            <div className="cart-items">
                {cartItems.map(item => (
                <div key={item.produk.id} className="cart-item">
                    <div className="item-info">
                    <h4>{item.produk.nama_produk}</h4>
                    <p>Rp {item.produk.harga.toLocaleString('id-ID')}</p>
                    </div>
                    <div className="quantity-controls">
                    <button 
                        onClick={() => updateQuantity(item.produk.id, item.quantity - 1)}
                    >
                        -
                    </button>
                    <span>{item.quantity}</span>
                    <button 
                        onClick={() => updateQuantity(item.produk.id, item.quantity + 1)}
                    >
                        +
                    </button>
                    </div>
                    <div className="item-subtotal">
                    Rp {(item.produk.harga * item.quantity).toLocaleString('id-ID')}
                    </div>
                    <button 
                    className="btn-danger btn-sm"
                    onClick={() => removeFromCart(item.produk.id)}
                    >
                    Hapus
                    </button>
                </div>
                ))}
            </div>

            {cartItems.length > 0 && (
                <div className="payment-section">
                <div className="total">
                    <strong>Total: Rp {getTotalPrice().toLocaleString('id-ID')}</strong>
                </div>

                <form onSubmit={handlePaymentSubmit}>
                    <div className="form-group">
                    <label>Jumlah Bayar:</label>
                    <input
                        type="number"
                        value={paymentForm.jumlahBayar}
                        onChange={(e) => setPaymentForm({
                        ...paymentForm,
                        jumlahBayar: e.target.value
                        })}
                        min={getTotalPrice()}
                        step="1000"
                        required
                        disabled={submitting}
                    />
                    </div>

                    <div className="form-group">
                    <label>Tipe Pembayaran:</label>
                    <select
                        value={paymentForm.tipePembayaran}
                        onChange={(e) => setPaymentForm({
                        ...paymentForm,
                        tipePembayaran: e.target.value as 'CASH' | 'DEBIT' | 'KREDIT'
                        })}
                        disabled={submitting}
                    >
                        <option value="CASH">Cash</option>
                        <option value="DEBIT">Debit</option>
                        <option value="KREDIT">Kredit</option>
                    </select>
                    </div>

                    {paymentForm.jumlahBayar && (
                    <div className="change-info">
                        <p>Kembalian: Rp {Math.max(0, parseFloat(paymentForm.jumlahBayar || '0') - getTotalPrice()).toLocaleString('id-ID')}</p>
                    </div>
                    )}

                    <button 
                    type="submit" 
                    className="btn-primary btn-large"
                    disabled={submitting}
                    >
                    {submitting ? 'Memproses...' : 'Bayar & Cetak Struk'}
                    </button>
                </form>
                </div>
            )}
            </div>
        </div>
        </div>
    );
};

export default Cart;