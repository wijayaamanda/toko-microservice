import React, { useState } from 'react';
import Sidebar from './Sidebar';
import ProdukList from '../Produk/ProdukList';
import OrderList from '../Order/OrderList';
import Cart from '../Order/Cart';
import { User } from '../../types';

interface MainLayoutProps {
    user: User;
    onLogout: () => void;
    }

    const MainLayout: React.FC<MainLayoutProps> = ({ user, onLogout }) => {
    const [activeMenu, setActiveMenu] = useState('dashboard');

    const renderContent = () => {
        switch (activeMenu) {
        case 'produk':
            return <ProdukList />;
        case 'orders':
            return <OrderList />;
        case 'cart':
            return <Cart />;
        case 'dashboard':
        default:
            return (
            <div className="dashboard">
                <h2>Dashboard</h2>
                <div className="dashboard-cards">
                <div className="card">
                    <h3>Selamat Datang!</h3>
                    <p>Halo {user.nama_pengguna}, selamat datang di sistem toko mikroservice.</p>
                </div>
                <div className="card">
                    <h3>Menu Utama</h3>
                    <ul>
                    <li>Kelola Produk - Tambah, edit, hapus produk</li>
                    <li>Transaksi - Lihat riwayat transaksi</li>
                    <li>Keranjang - Buat transaksi baru</li>
                    </ul>
                </div>
                </div>
            </div>
            );
        }
    };

    return (
        <div className="main-layout">
        <Sidebar
            user={user}
            activeMenu={activeMenu}
            onMenuClick={setActiveMenu}
            onLogout={onLogout}
        />
        <div className="main-content">
            {renderContent()}
        </div>
        </div>
    );
};

export default MainLayout;