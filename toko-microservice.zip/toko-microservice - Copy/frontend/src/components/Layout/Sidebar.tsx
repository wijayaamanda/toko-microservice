import React from 'react';
import { User } from '../../types';

interface SidebarProps {
    user: User;
    activeMenu: string;
    onMenuClick: (menu: string) => void;
    onLogout: () => void;
    }

    const Sidebar: React.FC<SidebarProps> = ({ user, activeMenu, onMenuClick, onLogout }) => {
    const menuItems = [
        { id: 'dashboard', label: 'Dashboard', icon: '📊' },
        { id: 'produk', label: 'Produk', icon: '📦' },
        { id: 'orders', label: 'Transaksi', icon: '🛒' },
        { id: 'cart', label: 'Keranjang', icon: '🛍️' }
    ];

    return (
        <div className="sidebar">
        <div className="sidebar-header">
            <h3>Toko Mikroservice</h3>
            <div className="user-info">
            <p><strong>{user.nama_pengguna}</strong></p>
            <p className="role">{user.role}</p>
            </div>
        </div>

        <nav className="sidebar-nav">
            {menuItems.map(item => (
            <button
                key={item.id}
                className={`nav-item ${activeMenu === item.id ? 'active' : ''}`}
                onClick={() => onMenuClick(item.id)}
            >
                <span className="nav-icon">{item.icon}</span>
                <span className="nav-label">{item.label}</span>
            </button>
            ))}
        </nav>

        <div className="sidebar-footer">
            <button className="btn-logout" onClick={onLogout}>
            🚪 Keluar
            </button>
        </div>
        </div>
    );
};

export default Sidebar;