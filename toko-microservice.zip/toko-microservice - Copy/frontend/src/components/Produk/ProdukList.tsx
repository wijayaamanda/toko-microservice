import React, { useState, useEffect } from 'react';
import { Produk } from '../../types';
import { produkService } from '../../services/apiService';
import ProdukForm from './ProdukForm';

const ProdukList: React.FC = () => {
    const [produk, setProduk] = useState<Produk[]>([]);
    const [loading, setLoading] = useState(true);
    const [showForm, setShowForm] = useState(false);
    const [editingProduk, setEditingProduk] = useState<Produk | null>(null);
    const [error, setError] = useState('');

    useEffect(() => {
        loadProduk();
    }, []);

    const loadProduk = async () => {
        try {
        setLoading(true);
        const result = await produkService.getAll();
        if (result.success && result.data) {
            setProduk(result.data);
        }
        } catch (err: any) {
        setError('Gagal memuat produk');
        console.error(err);
        } finally {
        setLoading(false);
        }
    };

    const handleDelete = async (id: number) => {
        if (window.confirm('Yakin ingin menghapus produk ini?')) {
        try {
            await produkService.delete(id);
            loadProduk();
        } catch (err) {
            alert('Gagal menghapus produk');
        }
        }
    };

    const handleEdit = (produk: Produk) => {
        setEditingProduk(produk);
        setShowForm(true);
    };

    const handleFormSuccess = () => {
        setShowForm(false);
        setEditingProduk(null);
        loadProduk();
    };

    const handleFormCancel = () => {
        setShowForm(false);
        setEditingProduk(null);
    };

    if (loading) return <div className="loading">Memuat produk...</div>;

    return (
        <div className="produk-list">
        <div className="page-header">
            <h2>Kelola Produk</h2>
            <button 
            className="btn-primary"
            onClick={() => setShowForm(true)}
            >
            Tambah Produk
            </button>
        </div>

        {error && <div className="error-message">{error}</div>}

        {showForm && (
            <ProdukForm
            produk={editingProduk}
            onSuccess={handleFormSuccess}
            onCancel={handleFormCancel}
            />
        )}

        <div className="produk-grid">
            {produk.length === 0 ? (
            <p>Belum ada produk.</p>
            ) : (
            produk.map(produk => (
                <div key={produk.id} className="produk-card">
                <div className="produk-info">
                    <h3>{produk.nama_produk}</h3>
                    <p className="price">Rp {produk.harga.toLocaleString('id-ID')}</p>
                    <p className="stock">Stok: {produk.stok}</p>
                    {produk.kategori && <p className="category">{produk.kategori}</p>}
                    {produk.deskripsi && <p className="description">{produk.deskripsi}</p>}
                </div>
                <div className="produk-actions">
                    <button 
                    className="btn-secondary"
                    onClick={() => handleEdit(produk)}
                    >
                    Edit
                    </button>
                    <button 
                    className="btn-danger"
                    onClick={() => handleDelete(produk.id)}
                    >
                    Hapus
                    </button>
                </div>
                </div>
            ))
            )}
        </div>
        </div>
    );
};

export default ProdukList;