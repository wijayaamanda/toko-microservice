import React, { useState } from 'react';
import { Produk } from '../../types';

interface ProdukTableProps {
    produk: Produk[];
    loading: boolean;
    onEdit: (produk: Produk) => void;
    onDelete: (id: number) => void;
}

const ProdukTable: React.FC<ProdukTableProps> = ({ produk, loading, onEdit, onDelete }) => {
    const [sortField, setSortField] = useState<keyof Produk>('nama_produk');
    const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('asc');
    const [searchTerm, setSearchTerm] = useState('');
    const [filterKategori, setFilterKategori] = useState('');

    const categories = Array.from(new Set(produk.map(p => p.kategori).filter(Boolean)));

    const filteredProduk = produk
        .filter(p => {
        const matchesSearch = p.nama_produk.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            (p.deskripsi && p.deskripsi.toLowerCase().includes(searchTerm.toLowerCase()));
        const matchesCategory = !filterKategori || p.kategori === filterKategori;
        return matchesSearch && matchesCategory;
        })
        .sort((a, b) => {
        const aValue = a[sortField];
        const bValue = b[sortField];
        
        if (typeof aValue === 'string' && typeof bValue === 'string') {
            return sortDirection === 'asc' 
            ? aValue.localeCompare(bValue)
            : bValue.localeCompare(aValue);
        }
        
        if (typeof aValue === 'number' && typeof bValue === 'number') {
            return sortDirection === 'asc' 
            ? aValue - bValue
            : bValue - aValue;
        }
        
        return 0;
        });

    const handleSort = (field: keyof Produk) => {
        if (sortField === field) {
        setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
        } else {
        setSortField(field);
        setSortDirection('asc');
        }
    };

    const handleDelete = (id: number, namaProduk: string) => {
        if (window.confirm(`Yakin ingin menghapus produk "${namaProduk}"?`)) {
        onDelete(id);
        }
    };

    const getSortIcon = (field: keyof Produk) => {
        if (sortField !== field) return '↕️';
        return sortDirection === 'asc' ? '↑' : '↓';
    };

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('id-ID', {
        style: 'currency',
        currency: 'IDR',
        minimumFractionDigits: 0
        }).format(amount);
    };

    const getStockStatus = (stok: number) => {
        if (stok === 0) return { class: 'status-out', text: 'Habis' };
        if (stok <= 10) return { class: 'status-low', text: 'Rendah' };
        return { class: 'status-good', text: 'Tersedia' };
    };

    if (loading) {
        return <div className="loading">Memuat produk...</div>;
    }

    return (
        <div className="produk-table-container">
        {/* Search and Filter Controls */}
        <div className="table-controls">
            <div className="search-controls">
            <div className="form-group">
                <input
                type="text"
                placeholder="Cari produk..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="search-input"
                />
            </div>
            
            <div className="form-group">
                <select
                value={filterKategori}
                onChange={(e) => setFilterKategori(e.target.value)}
                className="filter-select"
                >
                <option value="">Semua Kategori</option>
                {categories.map(category => (
                    <option key={category} value={category}>
                    {category}
                    </option>
                ))}
                </select>
            </div>
            </div>

            <div className="table-info">
            <span>Total: {filteredProduk.length} produk</span>
            </div>
        </div>

        {/* Table */}
        <div className="produk-table">
            {filteredProduk.length === 0 ? (
            <div className="no-data">
                {searchTerm || filterKategori ? 
                'Tidak ada produk yang sesuai dengan pencarian.' : 
                'Belum ada produk yang ditambahkan.'
                }
            </div>
            ) : (
            <table>
                <thead>
                <tr>
                    <th onClick={() => handleSort('nama_produk')} className="sortable">
                    Nama Produk {getSortIcon('nama_produk')}
                    </th>
                    <th onClick={() => handleSort('kategori')} className="sortable">
                    Kategori {getSortIcon('kategori')}
                    </th>
                    <th onClick={() => handleSort('harga')} className="sortable">
                    Harga {getSortIcon('harga')}
                    </th>
                    <th onClick={() => handleSort('stok')} className="sortable">
                    Stok {getSortIcon('stok')}
                    </th>
                    <th>Status</th>
                    <th>Deskripsi</th>
                    <th onClick={() => handleSort('created_at')} className="sortable">
                    Dibuat {getSortIcon('created_at')}
                    </th>
                    <th>Aksi</th>
                </tr>
                </thead>
                <tbody>
                {filteredProduk.map(item => {
                    const stockStatus = getStockStatus(item.stok);
                    return (
                    <tr key={item.id}>
                        <td>
                        <div className="produK-name">
                            <strong>{item.nama_produk}</strong>
                        </div>
                        </td>
                        <td>
                        {item.kategori && (
                            <span className="category-tag">
                            {item.kategori}
                            </span>
                        )}
                        </td>
                        <td className="price-cell">
                        {formatCurrency(item.harga)}
                        </td>
                        <td className="stock-cell">
                        <span className="stock-number">{item.stok}</span>
                        </td>
                        <td>
                        <span className={`stock-status ${stockStatus.class}`}>
                            {stockStatus.text}
                        </span>
                        </td>
                        <td className="description-cell">
                        {item.deskripsi ? (
                            <span title={item.deskripsi}>
                            {item.deskripsi.length > 50 
                                ? item.deskripsi.substring(0, 50) + '...' 
                                : item.deskripsi
                            }
                            </span>
                        ) : (
                            <span className="no-description">-</span>
                        )}
                        </td>
                        <td className="date-cell">
                        {new Date(item.created_at).toLocaleDateString('id-ID')}
                        </td>
                        <td className="action-cell">
                        <div className="action-buttons">
                            <button 
                            className="btn-secondary btn-sm"
                            onClick={() => onEdit(item)}
                            title="Edit produk"
                            >
                            ✏️
                            </button>
                            <button 
                            className="btn-danger btn-sm"
                            onClick={() => handleDelete(item.id, item.nama_produk)}
                            title="Hapus produk"
                            >
                            🗑️
                            </button>
                        </div>
                        </td>
                    </tr>
                    );
                })}
                </tbody>
            </table>
            )}
        </div>
        </div>
    );
};

export default ProdukTable;