import React, { useState, useEffect } from 'react';
import { Produk } from '../../types';
import { produkService } from '../../services/apiService';

interface ProdukFormProps {
  produk?: Produk | null;
  onSuccess: () => void;
  onCancel: () => void;
}

const ProdukForm: React.FC<ProdukFormProps> = ({ produk, onSuccess, onCancel }) => {
  const [formData, setFormData] = useState({
    namaProduk: '',
    harga: '',
    stok: '',
    deskripsi: '',
    kategori: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (produk) {
      setFormData({
        namaProduk: produk.nama_produk,
        harga: produk.harga.toString(),
        stok: produk.stok.toString(),
        deskripsi: produk.deskripsi || '',
        kategori: produk.kategori || ''
      });
    }
  }, [produk]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    if (!formData.namaProduk.trim()) {
      setError('Nama produk wajib diisi');
      setLoading(false);
      return;
    }

    if (parseFloat(formData.harga) <= 0) {
      setError('Harga harus lebih dari 0');
      setLoading(false);
      return;
    }

    if (parseInt(formData.stok) < 0) {
      setError('Stok tidak boleh negatif');
      setLoading(false);
      return;
    }

    try {
      const produkData = {
        nama_produk: formData.namaProduk.trim(),
        harga: parseFloat(formData.harga),
        stok: parseInt(formData.stok),
        deskripsi: formData.deskripsi.trim(),
        kategori: formData.kategori.trim()
      };

      if (produk) {
        await produkService.update(produk.id, produkData);
      } else {
        await produkService.create(produkData);
      }

      onSuccess();
    } catch (err: any) {
      setError(err.response?.data?.message || 'Terjadi kesalahan');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="modal-overlay">
      <div className="modal">
        <div className="modal-header">
          <h3>{produk ? 'Edit Produk' : 'Tambah Produk'}</h3>
          <button 
            type="button" 
            className="btn-close" 
            onClick={onCancel}
            disabled={loading}
          >
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit}>
          {error && <div className="error-message">{error}</div>}

          <div className="form-group">
            <label htmlFor="namaProduk">Nama Produk:</label>
            <input
              type="text"
              id="namaProduk"
              name="namaProduk"
              value={formData.namaProduk}
              onChange={handleInputChange}
              required
              disabled={loading}
              placeholder="Masukkan nama produk"
            />
          </div>

          <div className="form-row">
            <div className="form-group">
              <label htmlFor="harga">Harga:</label>
              <input
                type="number"
                id="harga"
                name="harga"
                value={formData.harga}
                onChange={handleInputChange}
                required
                disabled={loading}
                min="0"
                step="1000"
                placeholder="0"
              />
            </div>

            <div className="form-group">
              <label htmlFor="stok">Stok:</label>
              <input
                type="number"
                id="stok"
                name="stok"
                value={formData.stok}
                onChange={handleInputChange}
                required
                disabled={loading}
                min="0"
                placeholder="0"
              />
            </div>
          </div>

          <div className="form-group">
            <label htmlFor="kategori">Kategori:</label>
            <input
              type="text"
              id="kategori"
              name="kategori"
              value={formData.kategori}
              onChange={handleInputChange}
              disabled={loading}
              placeholder="Kategori produk (opsional)"
            />
          </div>

          <div className="form-group">
            <label htmlFor="deskripsi">Deskripsi:</label>
            <textarea
              id="deskripsi"
              name="deskripsi"
              value={formData.deskripsi}
              onChange={handleInputChange}
              disabled={loading}
              rows={3}
              placeholder="Deskripsi produk (opsional)"
            />
          </div>

          <div className="form-actions">
            <button 
              type="button" 
              className="btn-secondary" 
              onClick={onCancel}
              disabled={loading}
            >
              Batal
            </button>
            <button 
              type="submit" 
              className="btn-primary" 
              disabled={loading}
            >
              {loading ? 'Menyimpan...' : (produk ? 'Update' : 'Simpan')}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default ProdukForm;