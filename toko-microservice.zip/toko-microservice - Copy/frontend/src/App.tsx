import React, { useState, useEffect } from 'react';
import Login from './components/Auth/Login';
import Register from './components/Auth/Register';
import MainLayout from './components/Layout/MainLayout';
import { User } from './types';
import './App.css';

type AuthMode = 'login' | 'register';

const App: React.FC = () => {
    const [user, setUser] = useState<User | null>(null);
    const [authMode, setAuthMode] = useState<AuthMode>('login');
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        // Check if user is already logged in
        const savedUser = localStorage.getItem('user');
        const token = localStorage.getItem('token');
        
        if (savedUser && token) {
        try {
            setUser(JSON.parse(savedUser));
        } catch (err) {
            localStorage.removeItem('user');
            localStorage.removeItem('token');
        }
        }
        
        setLoading(false);
    }, []);

    const handleLoginSuccess = (userData: User) => {
        setUser(userData);
    };

    const handleLogout = () => {
        localStorage.removeItem('user');
        localStorage.removeItem('token');
        setUser(null);
    };

    const handleRegisterSuccess = () => {
        setAuthMode('login');
    };

    if (loading) {
        return (
        <div className="loading-screen">
            <div className="loading">Memuat aplikasi...</div>
        </div>
        );
    }

    if (!user) {
        return (
        <div className="auth-container">
            <div className="auth-wrapper">
            <div className="auth-header">
                <h1>Toko Mikroservice</h1>
                <p>Sistem Manajemen Produk & Transaksi</p>
            </div>
            
            {authMode === 'login' ? (
                <Login 
                onLoginSuccess={handleLoginSuccess}
                onSwitchToRegister={() => setAuthMode('register')}
                />
            ) : (
                <Register
                onRegisterSuccess={handleRegisterSuccess}
                onSwitchToLogin={() => setAuthMode('login')}
                />
            )}
            </div>
        </div>
        );
    }

    return (
        <MainLayout 
        user={user}
        onLogout={handleLogout}
        />
    );
};

export default App;