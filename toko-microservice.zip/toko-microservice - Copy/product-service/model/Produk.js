const db = require("../config/database");

class Produk {
    static async getAll() {
        const result = await db.query(
        "SELECT * FROM produk ORDER BY created_at DESC"
        );
        return result.rows;
    }

    static async getById(id) {
        const result = await db.query("SELECT * FROM produk WHERE id = $1", [id]);
        return result.rows[0];
    }

    static async create(produkData) {
        const { nama_produk, harga, stok, deskripsi, kategori } = produkData;

        const result = await db.query(
        `INSERT INTO produk (nama_produk, harga, stok, deskripsi, kategori)
        VALUES ($1, $2, $3, $4, $5)
        RETURNING id, nama_produk, harga, stok, deskripsi, kategori`,
        [nama_produk, harga, stok, deskripsi, kategori]
        );

        return result.rows[0];
    }

    static async update(id, produkData) {
        const { nama_produk, harga, stok, deskripsi, kategori } = produkData;

        const result = await db.query(
        `UPDATE produk
        SET nama_produk = $1, harga = $2, stok = $3, deskripsi = $4, kategori = $5,
            updated_at = CURRENT_TIMESTAMP
        WHERE id = $6
        RETURNING id`,
        [nama_produk, harga, stok, deskripsi, kategori, id]
        );

        return result.rowCount > 0;
    }

    static async delete(id) {
        const result = await db.query("DELETE FROM produk WHERE id = $1", [id]);
        return result.rowCount > 0;
    }

    static async updateStock(id, newStock) {
        const result = await db.query(
        "UPDATE produk SET stok = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2 RETURNING id",
        [newStock, id]
        );
        return result.rowCount > 0;
    }
}

module.exports = Produk;
