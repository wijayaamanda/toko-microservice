const { Pool } = require('pg');

const pool = new Pool({
    host: process.env.DB_HOST || 'product-db',
    port: process.env.DB_PORT || 5432,
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'password123',
    database: process.env.DB_NAME || 'product_service'
});

(async () => {
    try {
        await pool.query(`
            CREATE TABLE IF NOT EXISTS produk (
                id SERIAL PRIMARY KEY,
                nama_produk VARCHAR(255) NOT NULL,
                harga DECIMAL(10, 2) NOT NULL,
                stok INT NOT NULL DEFAULT 0,
                deskripsi TEXT,
                kategori VARCHAR(100),
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        `);
        console.log('Tabel produk siap digunakan');
    } catch (err) {
        console.error('Error membuat tabel produk:', err);
    }
})();

module.exports = pool;