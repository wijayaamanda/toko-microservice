const express = require("express");
const jwt = require("jsonwebtoken");
const Produk = require("../model/Produk");

const router = express.Router();
const JWT_SECRET = "toko_microservice_secret_key_2024";

const verifyToken = (req, res, next) => {
    const token = req.header("Authorization")?.replace("Bearer ", "");
    if (!token) {
        return res
        .status(401)
        .json({ success: false, message: "Token tidak ditemukan" });
    }
    try {
        const decoded = jwt.verify(token, JWT_SECRET);
        req.user = decoded;
        next();
    } catch (error) {
        res.status(401).json({ success: false, message: "Token tidak valid" });
    }
};

router.get("/", verifyToken, async (req, res) => {
    try {
        const produk = await Produk.getAll();
        res.json({ success: true, data: produk });
    } catch (error) {
        console.error("Error get produk:", error);
        res
        .status(500)
        .json({ success: false, message: "Terjadi kesalahan server" });
    }
});

router.get("/:id", verifyToken, async (req, res) => {
    try {
        const produkId = parseInt(req.params.id, 10);
        if (isNaN(produkId)) {
        return res
            .status(400)
            .json({ success: false, message: "ID produk harus berupa angka" });
        }

        const produk = await Produk.getById(produkId);
        if (!produk) {
        return res
            .status(404)
            .json({ success: false, message: "Produk tidak ditemukan" });
        }

        res.json({ success: true, data: produk });
    } catch (error) {
        console.error("Error get produk:", error);
        res
        .status(500)
        .json({ success: false, message: "Terjadi kesalahan server" });
    }
});

router.post("/", verifyToken, async (req, res) => {
    try {
        const { nama_produk, harga, stok, deskripsi, kategori } = req.body;

        if (!nama_produk || harga === undefined || stok === undefined) {
        return res.status(400).json({
            success: false,
            message: "Nama produk, harga, dan stok wajib diisi",
        });
        }

        if (isNaN(harga) || isNaN(stok)) {
        return res.status(400).json({
            success: false,
            message: "Harga dan stok harus berupa angka",
        });
        }

        const newProduk = await Produk.create({
        nama_produk: nama_produk,
        harga: parseFloat(harga),
        stok: parseInt(stok),
        deskripsi,
        kategori,
        });

        res.status(201).json({
        success: true,
        message: "Produk berhasil ditambahkan",
        data: newProduk,
        });
    } catch (error) {
        console.error("Error create produk:", error);
        res
        .status(500)
        .json({ success: false, message: "Terjadi kesalahan server" });
    }
});

router.put("/:id", verifyToken, async (req, res) => {
    try {
        const produkId = parseInt(req.params.id, 10);
        if (isNaN(produkId)) {
        return res
            .status(400)
            .json({ success: false, message: "ID produk harus berupa angka" });
        }

        const { nama_produk, harga, stok, deskripsi, kategori } = req.body;
        if (!nama_produk || harga === undefined || stok === undefined) {
        return res.status(400).json({
            success: false,
            message: "Nama produk, harga, dan stok wajib diisi",
        });
        }

        const updated = await Produk.update(produkId, {
        nama_produk,
        harga: parseFloat(harga),
        stok: parseInt(stok),
        deskripsi,
        kategori,
        });

        if (!updated) {
        return res
            .status(404)
            .json({ success: false, message: "Produk tidak ditemukan" });
        }

        res.json({ success: true, message: "Produk berhasil diupdate" });
    } catch (error) {
        console.error("Error update produk:", error);
        res
        .status(500)
        .json({ success: false, message: "Terjadi kesalahan server" });
    }
});

router.delete("/:id", verifyToken, async (req, res) => {
    try {
        const produkId = parseInt(req.params.id, 10);
        if (isNaN(produkId)) {
        return res
            .status(400)
            .json({ success: false, message: "ID produk harus berupa angka" });
        }

        const deleted = await Produk.delete(produkId);
        if (!deleted) {
        return res
            .status(404)
            .json({ success: false, message: "Produk tidak ditemukan" });
        }

        res.json({ success: true, message: "Produk berhasil dihapus" });
    } catch (error) {
        console.error("Error delete produk:", error);
        res
        .status(500)
        .json({ success: false, message: "Terjadi kesalahan server" });
    }
});

router.patch("/:id/stock", verifyToken, async (req, res) => {
    try {
        const produkId = parseInt(req.params.id, 10);
        if (isNaN(produkId)) {
        return res
            .status(400)
            .json({ success: false, message: "ID produk harus berupa angka" });
        }

        const { stok } = req.body;
        if (stok === undefined || isNaN(stok)) {
        return res
            .status(400)
            .json({ success: false, message: "Stok harus berupa angka" });
        }

        const updated = await Produk.updateStock(produkId, parseInt(stok));
        if (!updated) {
        return res
            .status(404)
            .json({ success: false, message: "Produk tidak ditemukan" });
        }

        res.json({ success: true, message: "Stok berhasil diupdate" });
    } catch (error) {
        console.error("Error update stock:", error);
        res
        .status(500)
        .json({ success: false, message: "Terjadi kesalahan server" });
    }
});

module.exports = router;