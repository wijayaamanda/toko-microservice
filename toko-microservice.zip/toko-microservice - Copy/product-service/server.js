const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const produkRoutes = require('./routes/produkRoutes');

const app = express();
const PORT = process.env.PORT || 3002;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use('/api/product', produkRoutes);

app.get('/', (req, res) => {
    res.json({ status: 'Product Service berjalan' });
});

app.listen(PORT, () => {
    console.log(`Product Service berjalan di port ${PORT}`);
});