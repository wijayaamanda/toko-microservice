const express = require("express");
const { createProxyMiddleware } = require("http-proxy-middleware");

const router = express.Router();

router.get("/tes", function (req, res) {
    console.log("[TEST] /api/tes endpoint hit");
    res.json({
        success: true,
        message: "Test endpoint working",
        timestamp: new Date().toISOString(),
    });
});

router.use((req, res, next) => {
    console.log(`[ROUTER] ${req.method} ${req.originalUrl}`);
    next();
});

const proxyConfig = {
    changeOrigin: true,
    timeout: 60000,
    proxyTimeout: 60000,
    preserveHeaderKeyCase: true,
    agent: false,
    headers: {
        Connection: "close",
    },
};

router.use(
    "/auth",
    createProxyMiddleware({
        target: "http://user-service:3001",
        ...proxyConfig,

    onProxyReq: (proxyReq, req, res) => {
        console.log(`[AUTH] >>> Proxying ${req.method} to ${req.originalUrl}`);

        if (req.method === "POST" && req.body) {
            const bodyData = JSON.stringify(req.body);
            proxyReq.setHeader("Content-Type", "application/json");
            proxyReq.setHeader("Content-Length", Buffer.byteLength(bodyData));
            console.log(`[AUTH] >>> Writing body:`, req.body);
            proxyReq.write(bodyData);
        }
        },

        onProxyRes: (proxyRes, req, res) => {
        console.log(`[AUTH] <<< Response ${proxyRes.statusCode} received`);
        },

        onError: (err, req, res) => {
        console.error(`[AUTH] Proxy Error:`, err.message);
        if (!res.headersSent) {
            res.status(500).json({
            error: "Auth service connection failed",
            details: err.message,
            });
        }
        },
    })
);

router.use(
    "/product",
    createProxyMiddleware({
        target: "http://product-service:3002",
        ...proxyConfig,

    onProxyReq: (proxyReq, req, res) => {
        console.log(`[PRODUCT] >>> Proxying ${req.method} to ${req.originalUrl}`);

        if ((req.method === "POST" || req.method === "PUT" || req.method === "PATCH") && req.body) {
            const bodyData = JSON.stringify(req.body);
            proxyReq.setHeader("Content-Type", "application/json");
            proxyReq.setHeader("Content-Length", Buffer.byteLength(bodyData));
            console.log(`[PRODUCT] >>> Writing body:`, req.body);
            proxyReq.write(bodyData);
        }
        },

        onProxyRes: (proxyRes, req, res) => {
        console.log(`[PRODUCT] <<< Response ${proxyRes.statusCode} received`);
        },

        onError: (err, req, res) => {
        console.error(`[PRODUCT] Proxy Error:`, err.message);
        if (!res.headersSent) {
            res.status(500).json({
            error: "Product service connection failed",
            details: err.message,
            });
        }
        },
    })
);

router.use(
    "/orders",
    createProxyMiddleware({
        target: "http://order-service:3003",
        ...proxyConfig,
        pathRewrite: { "^/api/orders": "/api" },

    onProxyReq: (proxyReq, req, res) => {
        console.log(`[ORDER] >>> Proxying ${req.method} to ${req.originalUrl}`);

        if (req.method === "POST" && req.body) {
            const bodyData = JSON.stringify(req.body);
            proxyReq.setHeader("Content-Type", "application/json");
            proxyReq.setHeader("Content-Length", Buffer.byteLength(bodyData));
            console.log(`[ORDER] >>> Writing body:`, req.body);
            proxyReq.write(bodyData);
        }
    },

    onProxyRes: (proxyRes, req, res) => {
        console.log(`[ORDER] <<< Response ${proxyRes.statusCode} received`);
    },

    onError: (err, req, res) => {
        console.error(`[ORDER] Proxy Error:`, err.message);
        if (!res.headersSent) {
            res.status(500).json({
            error: "Order service connection failed",
            details: err.message,
            });
        }
        },
    })
);

module.exports = router;
