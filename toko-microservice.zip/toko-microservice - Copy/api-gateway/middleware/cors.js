const cors = require('cors');

const corsOptions = {
    origin: [
        'http://localhost:3004',
        'http://localhost:3002',
        'http://localhost:3003',
        'http://127.0.0.1'
    ],
    credentials: true,
    optionsSuccessStatus: 200,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: [
        'Origin',
        'X-Requested-With', 
        'Content-Type',
        'Accept',
        'Authorization'
    ]
};

module.exports = cors(corsOptions);