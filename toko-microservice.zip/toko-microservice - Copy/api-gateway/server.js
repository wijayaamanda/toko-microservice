const express = require("express");
const cors = require("cors");
const bodyParser = require("body-parser");
const gatewayRoutes = require("./routes/gateway");

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

app.use((req, res, next) => {
    console.log(`${new Date().toISOString()} - ${req.method} ${req.originalUrl}`);
    next();
});

app.use("/api", gatewayRoutes);

app.get("/", (req, res) => {
    res.json({
        status: "API Gateway berjalan",
        port: PORT,
        environment: process.env.NODE_ENV || "development",
        services: {
        auth: "http://user-service:3001",
        product: "http://product-service:3002",
        order: "http://order-service:3003",
        },
    });
});

app.get("/test", (req, res) => {
    res.json({
        message: "Gateway test endpoint working",
        timestamp: new Date().toISOString(),
    });
});

app.listen(PORT, "0.0.0.0", () => {
    console.log(`API Gateway berjalan di port ${PORT}`);
    console.log(`Environment: ${process.env.NODE_ENV || "development"}`);
    console.log(`Access: http://localhost:${PORT}`);
});
