CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    nama_pengguna VARCHAR(100) NOT NULL UNIQUE,
    email VARCHAR(100) NOT NULL UNIQUE,
    no_telepon VARCHAR(20),
    kata_sandi VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'kasir' CHECK (role IN ('admin', 'kasir')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
