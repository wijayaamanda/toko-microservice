CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    kode_transaksi VARCHAR(50) UNIQUE NOT NULL,
    user_id INT NOT NULL,
    nama_kasir VARCHAR(100) NOT NULL,
    total_harga DECIMAL(10,2) NOT NULL,
    jumlah_bayar DECIMAL(10,2) NOT NULL,
    kembalian DECIMAL(10,2) NOT NULL,
    tipe_pembayaran VARCHAR(20) DEFAULT 'CASH',
    status VARCHAR(20) DEFAULT 'completed' CHECK (status IN ('pending', 'confirmed', 'processing', 'shipped', 'delivered', 'cancelled', 'refunded')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS order_items (
    id SERIAL PRIMARY KEY,
    order_id INT NOT NULL,
    produk_id INT NOT NULL,
    nama_produk VARCHAR(255) NOT NULL,
    harga DECIMAL(10,2) NOT NULL,
    jumlah INT NOT NULL CHECK (jumlah > 0),
    subtotal DECIMAL(10,2) NOT NULL CHECK (subtotal >= 0),
    CONSTRAINT fk_order FOREIGN KEY (order_id) REFERENCES orders(id) ON DELETE CASCADE
);